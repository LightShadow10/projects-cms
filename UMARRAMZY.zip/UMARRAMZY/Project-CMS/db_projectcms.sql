-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 20, 2024 at 06:32 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `auth_example`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE `artikel` (
  `id` int NOT NULL,
  `judul` varchar(255) NOT NULL,
  `konten` text NOT NULL,
  `penulis_id` int DEFAULT NULL,
  `kategori_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `artikel`
--

INSERT INTO `artikel` (`id`, `judul`, `konten`, `penulis_id`, `kategori_id`, `created_at`, `gambar`) VALUES
(26, 'Adu Banteng Timnas Indonesia Vs Filipina pada Kualifikasi Piala Dunia 2026 Zona Asia: Lini Tengah Bentrok', 'Kalah sebelum beperang sudah menghantui pelatih Timnas Filipina, Tom Saintfiet. Dalam jumpa wartawan jelang duel, Tom Saintfiet blak-blakan mengakui kalau Indonesia bukan tim sembarangan.\r\n\r\n\"Kami tahu, Timnas Indonesia adalah kekuaran baru di Asia yang sangat kuat,\" kata Tom Saintfiet.Tak ada yang salah dengan pernyataan Tom Saintfiet. Fakta berbicara, dalam dua tahun terakhir pencapaian Indonesia di Asia sangat mengagumkan. Belum lama ini, di Qatar, Timnas Indonesia U-23 2024 mampu merangsek ke semifinal setelah lebih dulu mendepak Jordania, Australia, dan Korea Selatan. Sebelumnya, timnas senior juga mampu melangkah ke Babak 16 Besar Piala Asia 2023.\r\n\r\nKebijakan Persatuan Sepak Bola Seluruh Indonesia (PSSI) di bawah arahan Erick Thohir membuka kran besar-besar kepada pemain keturunan yang bermain di Eropa via program naturalisi berdampak signifikan bagi kedigdayaan Timnas Indonesia.', 17, 2, '2024-06-10 03:45:41', 'Screenshot 2024-06-10 104511.png'),
(27, 'Fnatic ONIC Juara MPL ID S13, Rekor Baru Gelar Beruntun Keempat!', 'Fnatic ONIC sukses meraih gelar MPL ID Season 13 usai menundukkan Evos Glory dengan skor 4-2 di grand final, Minggu (9/6) di Jakarta International Velodrome, Jakarta. Tim berlogo landak kuning berjuluk \"Raja Galaksi\" berhasil menorehkan rekor tinta emas karena ini merupakan gelar juara MPL keempat secara beruntun! \r\n\r\nSempat diragukan di awal reguler season kalau era Onic sudah habis, CW yang terpilih sebagai MVP atau Pemain Terbaik di grand final memastikan kalau ini masih eranya Onic. Sambil tak lupa mengucapkan terima kasih atas kepercayaan dan dukungan sobat SONIC -fans setia ONIC, para punggawa Fnatic ONIC memancarkan rasa bangga, bahagia dan lega usai melalui laga sengit menghadapi Evos Glory. \r\n\r\nFnatic Onic sukses membuka game pertama seri BO-7 (best of seven) dengan meyakinkan. Kiboy dkk berhasil menambah keunggulan 2-0 lewat permainan dominan. Masuk ke game ke-3, Evos Glory memberi perlawanan lewat draft dan eksekusi solid. Namun, Onic berhasil membalikkan keadaan dan meraih kemenangan di menit 23, mengubah skor 3-0.\r\n\r\nPada kedudukan Match point, Onic hanya butuh satu game lagi. Evos Glory tak putus asa memberikan perlawanan. Jabran Bagus Wiloko \"Branz dan kawan-kawan berhasil mencuri poin dan mengubah skor sementara 1-3.\r\n\r\nMasuk ke game ke-5, Onic kembali memegang kendali, Pergerakan Kairi dan Kiboy menopang CW dan Lutpii berhasil meraih gold networth jauh di atas Evos. Namun, lagi-lagi aksi Branz berhasil menciptakan momentum comeback. Evos mengamuk dan berhasil 15  kill dan 5 death atas Fnatic Onic untuk menutup kemenangan di menit 16. Skor pun menjadi 2-3. Tekanan berbalik ke kubu Onic. \r\n\r\nDi game ke-6, Onic kembali memegang kendali permainan di early game. Seakan tak mau kecolongan atau lepas ritme, Sanz dkk tak memberi ruang bagi rotasi Evos yang sesekali menerapkan pola 3 -2. Onic sekan ingin membalaskan kekalahan di game sebelumnya dengan gameplay cepat alias fast end. Terbukti setela merebut lord ke-2, serangan Onic tak terbendung. CW sebagai marksman menghabisi hero Evos hingga Onic unggul jauh 9-1 jumlah kill.  Onic memastikan gelar juara setelah menghancurkan inhibitor Evos di menit 16. \r\n\r\nSebagai runner-up  grand final MPL ID S13 2024, Evos Glory akan mendampingi Onic berlaga di MSC 2024 di Riyadh.  \r\n\r\nIkuti terus info terbaru seputar Mobile Legends dan berita esports terlengkap di Ligagame! Jangan lupa kunjungi Instagram dan Youtube Ligagame.tv yang selalu update dan kekinian! ', 17, 12, '2024-06-10 04:16:38', 'Screenshot 2024-06-10 111534.png');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama`) VALUES
(1, 'Teknologi'),
(2, 'Olahraga'),
(3, 'Kesehatan'),
(12, 'Esport');

-- --------------------------------------------------------

--
-- Table structure for table `penulis`
--

CREATE TABLE `penulis` (
  `id` int NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penulis`
--

INSERT INTO `penulis` (`id`, `nama`) VALUES
(17, 'saya'),
(18, 'abdul jabbar');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `psw` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `psw`) VALUES
(2, 'admin', 'aku@gmail.com', '$2y$10$T/4JxvDeYrMiUrwpQBCb9Oraa4jMHNKHliCyXMehKaE0fF3KzZ7pW', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `penulis_id` (`penulis_id`),
  ADD KEY `kategori_id` (`kategori_id`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penulis`
--
ALTER TABLE `penulis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artikel`
--
ALTER TABLE `artikel`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `penulis`
--
ALTER TABLE `penulis`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `artikel`
--
ALTER TABLE `artikel`
  ADD CONSTRAINT `artikel_ibfk_1` FOREIGN KEY (`penulis_id`) REFERENCES `penulis` (`id`),
  ADD CONSTRAINT `artikel_ibfk_2` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
